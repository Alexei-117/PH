<article>
	<figure>
		<a href=
		<?php
			if(isset($_SESSION["nombre"])){
				echo "detalle.php?id=1";
			}else{
				echo "";
			}
		?>
		><img alt="última-foto-1" src="img/te_fo.jpg"/></a>
	</figure>
	<p>
		<b>titulo: selfie</b>
	</p>
	<p>
		<b>pais: india</b>
	</p>
	<p>
		<b>fecha: 14/3/2015</b>
	</p>
</article>
<article>
	<figure>
		<a href=		
		<?php
			if(isset($_SESSION["nombre"])){
				echo "detalle.php?id=2";
			}else{
				echo "";
			}
		?>><img alt="última-foto-2" src="img/si_o_que.jpg"/></a>
	</figure>
	<p>
		<b>titulo: party with my work mates!</b>
	</p>
	<p>
		<b>pais: new delhi</b>
	</p>
	<p>
		<b>fecha: 2/5/2015</b>
	</p>
</article>
<article>
	<figure>
		<a href=		
		<?php
			if(isset($_SESSION["nombre"])){
				echo "detalle.php?id=1";
			}else{
				echo "";
			}
		?>><img alt="última-foto-3" src="img/tio_maquina.jpg" /></a>
	</figure>
	<p>
		<b>titulo: yo guapo</b>
	</p>
	<p>
		<b>pais: new york</b>
	</p>
	<p>
		<b>fecha: 3/4/2015</b>
	</p>
</article>
<article>
	<figure>
		<a href=		
		<?php
			if(isset($_SESSION["nombre"])){
				echo "detalle.php?id=2";
			}else{
				echo "";
			}
		?>><img alt="última-foto-4" src="img/lacara.png"/></a>
	</figure>
	<p>
		<b>titulo: my son's first draw</b>
	</p>
	<p>
		<b>pais: spain</b>
	</p>
	<p>
		<b>fecha: 1/2/2015</b>
	</p>
</article>
<article>
	<figure>
		<a href=
			<?php
			if(isset($_SESSION["nombre"])){
				echo "detalle.php?id=1";
			}else{
				echo "";
			}
		?>><img alt="última-foto-5" src="img/soy_guapa.jpeg"/></a>
	</figure>
	<p>
		<b>titulo: i'm pretty!</b>
	</p>
	<p>
		<b>pais: england</b>
	</p>
	<p>
		<b>fecha: 11/10/2014</b>
	</p>
</article>